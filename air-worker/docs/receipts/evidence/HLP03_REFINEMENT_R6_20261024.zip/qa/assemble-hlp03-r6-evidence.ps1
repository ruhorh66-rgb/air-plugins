$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$awSource='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker'
$awTask='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker\.air-worker\learning-loop-20261024'
$awUTF8=New-Object Text.UTF8Encoding($false)
$awJobBase=Join-Path $awSource '.woody\jobs\gpt-hlp03-semantic-20261024-executor-LEARNING-HLP03-R6-INDEPENDENT-REVIEW-20261024-md-executor-codex-gpt-6-sol-medium'
$awJob=Get-Content -LiteralPath ($awJobBase+'.receipt.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($awJob.status -ne 'DONE'){throw 'Independent native job is not DONE'}
$awReviewPath=Join-Path $awSource 'docs\receipts\LEARNING_HLP03_R6_INDEPENDENT_REVIEW_20261024.json'
$awReview=Get-Content -LiteralPath $awReviewPath -Raw -Encoding UTF8 | ConvertFrom-Json
if($awReview.schema -ne 'air-worker.hlp03-r6-independent-review/v1'){throw 'Independent review schema'}
$awRows=New-Object 'System.Collections.Generic.List[object]'
function Add-AwEvidence([string]$Source,[string]$Name){
 $item=Get-Item -LiteralPath $Source -Force
 if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "Invalid evidence file: $Source"}
 $awRows.Add([pscustomobject][ordered]@{source=$item.FullName;path=$Name.Replace('\','/');bytes=[int64]$item.Length;sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()})
}
$awTrees=@(@{source=(Join-Path $awTask 'hlp03-r6-candidate-snapshot');prefix='candidate'})
foreach($kind in @('development','holdout','followup')){
 $dir=Join-Path $awTask ('hlp03-r6-'+$kind+'-20261024')
 if(Test-Path -LiteralPath $dir){$awTrees+=@{source=$dir;prefix=('runs/r6-'+$kind)}}
}
foreach($tree in $awTrees){
 foreach($file in @(Get-ChildItem -LiteralPath $tree.source -Recurse -File -Force | Sort-Object FullName)){
  Add-AwEvidence $file.FullName ($tree.prefix+'/'+$file.FullName.Substring($tree.source.Length+1))
 }
}
$awTaskFiles=@('hlp03-r6-source-qa.json','hlp03-r6-source-go-test.jsonl','hlp03-r6-source-vet.txt','hlp03-r6-source-build.txt','hlp03-r6-source-powershell.txt','hlp03-r6-preservation-before.json','hlp03-r6-postrun-readback.json','run-hlp03-r6-source-qa.ps1','freeze-hlp03-r6-candidate.ps1','assemble-hlp03-r6-evidence.ps1','hlp03-r6-c18-transport-readback.json','verify-hlp03-r6-c18-transport.ps1')
foreach($name in $awTaskFiles){Add-AwEvidence (Join-Path $awTask $name) ('qa/'+$name)}
$awInputs=@(
 'cmd\testdata\hlp03_reviewer_corpus_20261024_r4_development.json',
 'docs\tasks\HLP03_REVIEWER_GOLD_20261024_R4_DEVELOPMENT.json',
 'cmd\testdata\hlp03_reviewer_corpus_20261024_r5_holdout.json',
 'docs\tasks\HLP03_REVIEWER_GOLD_20261024_R5_HOLDOUT.json',
 'docs\tasks\HLP03_FOLLOWUP_DESIGN_20261024_R5.json',
 'docs\tasks\HLP03_REVIEWER_GOLD_20261024_R5_FOLLOWUP.json',
 'docs\tasks\HLP03_EVALUATION_PROTOCOL_20261024_R6.json',
 'docs\tasks\HLP03_CORPUS_FREEZE_20261024_R6_DEVELOPMENT.json',
 'docs\tasks\HLP03_CORPUS_FREEZE_20261024_R6_HOLDOUT.json',
 'docs\tasks\LEARNING_HLP03_REFINEMENT_R6_20261024.md',
 'docs\tasks\LEARNING_HLP03_R6_INDEPENDENT_REVIEW_20261024.md',
 'docs\receipts\LEARNING_HLP03_R6_AUTHOR_20261024.json',
 'docs\receipts\LEARNING_HLP03_R6_ADVANCE_GATE_20261024.json',
 'docs\receipts\LEARNING_HLP03_R6_COORDINATOR_REVIEW_20261024.json',
 'docs\receipts\LEARNING_HLP03_R6_INDEPENDENT_REVIEW_20261024.json',
 'docs\receipts\LEARNING_HLP03_R6_BOUNDARY_DIAGNOSIS_20261024.json',
 'docs\receipts\AIRWORKER_INTERMEDIATE_RELEASE_PREPARATION_20261024.json'
)
foreach($relative in $awInputs){Add-AwEvidence (Join-Path $awSource $relative) ('inputs/'+$relative)}
foreach($optional in @('cmd\testdata\hlp03_reviewer_corpus_20261024_r6_followup.json','docs\tasks\HLP03_CORPUS_FREEZE_20261024_R6_FOLLOWUP.json','docs\tasks\HLP03_FOLLOWUP_DERIVATION_20261024_R6.json')){
 $path=Join-Path $awSource $optional
 if(Test-Path -LiteralPath $path){Add-AwEvidence $path ('inputs/'+$optional)}
}
$awAuthorBase=Join-Path $awSource '.woody\jobs\gpt-hlp03-semantic-20261024-executor-LEARNING-HLP03-REFINEMENT-R6-20261024-md-executor-codex-gpt-6-sol-medium'
$awAuthor=Get-Content -LiteralPath ($awAuthorBase+'.receipt.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if($awAuthor.status -ne 'DONE'){throw 'Author job not DONE'}
Add-AwEvidence ($awAuthorBase+'.receipt.json') 'author/native-job.receipt.json'
Add-AwEvidence ($awAuthorBase+'.out') 'author/native-job.out'
Add-AwEvidence ($awJobBase+'.receipt.json') 'review/native-job.receipt.json'
Add-AwEvidence ($awJobBase+'.out') 'review/native-job.out'
if(@($awRows | Group-Object path | Where-Object Count -ne 1).Count){throw 'Duplicate archive names'}
$awManifest=[ordered]@{schema='air-worker.hlp03-r6-evidence-manifest/v1';created_at_utc=[DateTime]::UtcNow.ToString('o');source_base_sha='e6c3c7f960208b49bdd0b4e694bc7eb99554bdce';preserves_original_terminals=$true;designated_cases=32;actual_series=@($awTrees | Where-Object {$_.prefix -like 'runs/*'} | ForEach-Object {$_.prefix});binary_excluded='The measured QA executable remains at its task-owned absolute path, bound by SHA and the exact source snapshot; this archive is not a release package.';files=@($awRows | Sort-Object path)}
$awManifestText=$awManifest | ConvertTo-Json -Depth 12
$awZip=Join-Path $awSource 'docs\receipts\evidence\HLP03_REFINEMENT_R6_20261024.zip'
if(Test-Path -LiteralPath $awZip){throw 'Evidence archive exists; never overwrite'}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$awFile=[IO.File]::Open($awZip,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
$awArchive=New-Object IO.Compression.ZipArchive($awFile,[IO.Compression.ZipArchiveMode]::Create,$false)
try{
 foreach($row in $awManifest.files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($awArchive,$row.source,$row.path,[IO.Compression.CompressionLevel]::Optimal) | Out-Null}
 $awEntry=$awArchive.CreateEntry('EVIDENCE_MANIFEST.json')
 $awStream=$awEntry.Open()
 $awWriter=New-Object IO.StreamWriter($awStream,$awUTF8)
 try{$awWriter.Write($awManifestText)}finally{$awWriter.Dispose()}
}finally{$awArchive.Dispose();$awFile.Dispose()}
$awReader=[IO.Compression.ZipFile]::OpenRead($awZip)
$awVerified=0
try{
 if($awReader.Entries.Count -ne ($awManifest.files.Count+1)){throw 'Archive entry count mismatch'}
 foreach($row in $awManifest.files){
  $entry=$awReader.GetEntry($row.path)
  if($null -eq $entry -or $entry.Length -ne $row.bytes){throw "Archive size/entry mismatch: $($row.path)"}
  $stream=$entry.Open();$hash=[Security.Cryptography.SHA256]::Create()
  try{$sha=([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose();$stream.Dispose()}
  if($sha -ne $row.sha256){throw "Archive hash mismatch: $($row.path)"}
  if((Get-FileHash -LiteralPath $row.source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256){throw "Source drift while archiving: $($row.path)"}
  $awVerified++
 }
 $manifestEntry=$awReader.GetEntry('EVIDENCE_MANIFEST.json');$stream=$manifestEntry.Open();$reader=New-Object IO.StreamReader($stream,$awUTF8)
 try{if($reader.ReadToEnd() -cne $awManifestText){throw 'Manifest readback mismatch'}}finally{$reader.Dispose()}
}finally{$awReader.Dispose()}
$awResult=[ordered]@{schema='air-worker.hlp03-r6-evidence-bundle/v1';archive='docs/receipts/evidence/HLP03_REFINEMENT_R6_20261024.zip';sha256=(Get-FileHash -LiteralPath $awZip -Algorithm SHA256).Hash.ToLowerInvariant();bytes=(Get-Item -LiteralPath $awZip).Length;entries=($awVerified+1);manifest_files=$awVerified;every_entry_reopened_and_sha_verified=$true;original_files_unchanged_after_archive=$true;native_job_id=$awJob.job_id;native_job_status=$awJob.status;native_job_receipt_sha256=(Get-FileHash -LiteralPath ($awJobBase+'.receipt.json') -Algorithm SHA256).Hash.ToLowerInvariant();independent_review_sha256=(Get-FileHash -LiteralPath $awReviewPath -Algorithm SHA256).Hash.ToLowerInvariant();source_base_sha='e6c3c7f960208b49bdd0b4e694bc7eb99554bdce';measured_binary_sha256='97a07619b9ada8c444488e97b1b6c0f428af15f74fd7465f4c3d86188b739780';measured_adapter_sha256='bc630efcec6f50471b647722d56b18d7922f82ba3cd1db79f452095069314647';production_effect='NOT_PROVEN'}
[IO.File]::WriteAllText((Join-Path $awSource 'docs\receipts\LEARNING_HLP03_R6_EVIDENCE_BUNDLE_20261024.json'),($awResult | ConvertTo-Json -Depth 5),$awUTF8)
$awResult | ConvertTo-Json -Depth 5 -Compress