$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$p='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker'
$t='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker\.air-worker\learning-loop-20261024'
$u=New-Object Text.UTF8Encoding($false)
function SHA([string]$path){(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
$qaPath=Join-Path $t 'hlp03-r6-source-qa.json'
$qa=Get-Content -LiteralPath $qaPath -Raw -Encoding UTF8 | ConvertFrom-Json
if($qa.test_exit_code -ne 0 -or $qa.powershell_test_exit_code -ne 0 -or $qa.vet_exit_code -ne 0 -or $qa.build_exit_code -ne 0 -or $qa.diff_check_exit_code -ne 0){throw 'R6 source QA did not pass'}
if(([string](& git -C $p rev-parse HEAD)).Trim() -ne 'e6c3c7f960208b49bdd0b4e694bc7eb99554bdce'){throw 'R6 base drift'}
foreach($run in @('hlp03-r6-development-20261024','hlp03-r6-holdout-20261024','hlp03-r6-followup-20261024')){if(Test-Path -LiteralPath (Join-Path $t $run)){throw 'R6 model evidence already exists'}}
$pres=Get-Content -LiteralPath (Join-Path $t 'hlp03-r6-preservation-before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach($g in @($pres.guards)+@($pres.historical)){if((SHA $g.path) -ne $g.sha256){throw "Protected/historical drift: $($g.path)"}}
$binary=Join-Path $t 'air-worker-hlp03-r6.exe'
if((SHA $binary) -ne $qa.binary_sha256){throw 'QA binary drift'}
$hashes=[ordered]@{adapter_sha256=(SHA (Join-Path $p 'cmd\learn_adapter.go'));harness_sha256=(SHA (Join-Path $p 'cmd\learn_adapter_live_eval_test.go'));runner_sha256=(SHA (Join-Path $p 'docs\tasks\run-hlp03-real-reviewer-20261024.ps1'));runner_tests_sha256=(SHA (Join-Path $p 'docs\tasks\test-run-hlp03-real-reviewer-20261024.ps1'));binary_sha256=$qa.binary_sha256}
foreach($property in $qa.source_sha256.PSObject.Properties){if((SHA (Join-Path $p $property.Name)) -ne $property.Value){throw "QA source drift: $($property.Name)"}}
$snapshot=Join-Path $t 'hlp03-r6-candidate-snapshot'
if(Test-Path -LiteralPath $snapshot){throw 'R6 snapshot exists'}
New-Item -ItemType Directory -Path $snapshot | Out-Null
$sourceFiles=@('cmd\learn_adapter.go','cmd\learn_adapter_live_eval_test.go','cmd\go.mod','cmd\go.sum','docs\tasks\run-hlp03-real-reviewer-20261024.ps1','docs\tasks\test-run-hlp03-real-reviewer-20261024.ps1')
$rows=@(foreach($r in $sourceFiles){$src=Join-Path $p $r;$dst=Join-Path $snapshot $r;New-Item -ItemType Directory -Path (Split-Path -Parent $dst) -Force | Out-Null;[IO.File]::Copy($src,$dst,$false);if((SHA $src) -ne (SHA $dst)){throw 'Snapshot copy mismatch'};[ordered]@{path=$r;sha256=(SHA $src);bytes=(Get-Item -LiteralPath $src).Length}})
$manifest=[ordered]@{source_base_sha='e6c3c7f960208b49bdd0b4e694bc7eb99554bdce';candidate_hashes=$hashes;files=$rows}
[IO.File]::WriteAllText((Join-Path $snapshot 'manifest.json'),(($manifest|ConvertTo-Json -Depth 8).Replace("`r`n","`n")+"`n"),$u)
$protocolRelative='docs/tasks/HLP03_EVALUATION_PROTOCOL_20261024_R6.json'
$protocolSHA=SHA (Join-Path $p $protocolRelative)
$freezes=@()
foreach($series in @('DEVELOPMENT','HOLDOUT')){
 $oldPath=Join-Path $p ('docs\tasks\HLP03_CORPUS_FREEZE_20261024_R5_'+$series+'.json')
 $f=Get-Content -LiteralPath $oldPath -Raw -Encoding UTF8 | ConvertFrom-Json
 $newPath=Join-Path $p ('docs\tasks\HLP03_CORPUS_FREEZE_20261024_R6_'+$series+'.json')
 if(Test-Path -LiteralPath $newPath){throw 'R6 freeze already exists'}
 $f.series='HLP03_R6_'+$series+'_20261024'
 $f.frozen_at_utc=[DateTime]::UtcNow.ToString('o')
 $f.source_base_sha='e6c3c7f960208b49bdd0b4e694bc7eb99554bdce'
 $f.candidate_source_hashes=$hashes
 $f.protocol_path=$protocolRelative
 $f.protocol_sha256=$protocolSHA
 $f.source_qa_sha256=SHA $qaPath
 $f.PSObject.Properties.Remove('r5_learning_reviewer_calls_before_freeze')
 $f | Add-Member -NotePropertyName r6_learning_reviewer_calls_before_freeze -NotePropertyValue 0
 $f | Add-Member -NotePropertyName reuse_note -NotePropertyValue 'Known24 exact original inputs; fresh6 and old2 design reused from prospective R5 inputs never executed by the learning reviewer. Labels and input bytes unchanged.'
 if((SHA (Join-Path $p $f.corpus_path)) -ne $f.corpus_sha256 -or (SHA (Join-Path $p $f.gold_path)) -ne $f.gold_sha256){throw 'Original input drift'}
 [IO.File]::WriteAllText($newPath,(($f|ConvertTo-Json -Depth 15).Replace("`r`n","`n")+"`n"),$u)
 $freezes+=[ordered]@{path=$newPath;sha256=(SHA $newPath);cases=$f.case_count;corpus=$f.corpus_path;gold=$f.gold_path}
}
[ordered]@{candidate=$hashes;source_qa_sha256=(SHA $qaPath);snapshot_manifest_sha256=(SHA (Join-Path $snapshot 'manifest.json'));protocol_sha256=$protocolSHA;freezes=$freezes;preserved_guards=$pres.guards.Count;preserved_historical=$pres.historical.Count}|ConvertTo-Json -Depth 8 -Compress
