$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$p='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker'; $t='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker\.air-worker\learning-loop-20261024'
$dir=Join-Path $t 'hlp03-r6-development-20261024\evidence\C18'
function SHA([string]$f){(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLowerInvariant()}
$corpus=Get-Content -LiteralPath (Join-Path $p 'cmd\testdata\hlp03_reviewer_corpus_20261024_r4_development.json') -Raw -Encoding UTF8|ConvertFrom-Json
$case=@($corpus.cases|Where-Object id -eq 'C18')[0]
$packetText=[string](Get-Content -LiteralPath (Join-Path $dir 'packet.json') -Raw -Encoding UTF8)
$packet=$packetText|ConvertFrom-Json
$prompt=[string](Get-Content -LiteralPath (Join-Path $dir 'prompt.txt') -Raw -Encoding UTF8)
$native=[string](Get-Content -LiteralPath (Join-Path $dir 'native-prompt.txt') -Raw -Encoding UTF8)
$catalogue=Get-Content -LiteralPath (Join-Path $dir 'seed-catalogue.json') -Raw -Encoding UTF8|ConvertFrom-Json
$seed=@($catalogue|Where-Object target -eq 'skills/learned/closed-interval-overlap.md')[0]
$eventEqual=(@($case.event.PSObject.Properties).Count -eq @($packet.event.PSObject.Properties).Count)
foreach($prop in $case.event.PSObject.Properties){if([string]$prop.Value -cne [string]$packet.event.($prop.Name)){$eventEqual=$false}}
$hash=[Security.Cryptography.SHA256]::Create()
try{$seedSha=([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$seed.Body)))).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()}
$checks=[ordered]@{event_fields_equal_frozen_corpus=$eventEqual;prompt_contains_full_packet_json=$prompt.Contains($packetText.TrimEnd());native_prompt_contains_full_prompt=$native.Contains($prompt);prompt_contains_complete_overlap_seed=$prompt.Contains([string]$seed.Body);seed_body_sha_matches_catalogue=($seedSha -eq $seed.sha256);prompt_sha_matches_summary=((SHA (Join-Path $dir 'prompt.txt')) -eq 'b68241b50590615631959b7e71b32c5acf4197fe15dd13bd6d9b43c8ab9e7a2d');native_prompt_sha_matches_summary=((SHA (Join-Path $dir 'native-prompt.txt')) -eq '31124bdb84adaf5728ab6a989ee5b654d0f420858c4dd62c5bf4f0ad7bb5521b')}
if(@($checks.Values|Where-Object{-not $_}).Count){throw 'C18 captured evidence transport mismatch'}
$files=@(foreach($f in @('packet.json','prompt.txt','native-prompt.txt','seed-catalogue.json','adapter-raw.json','result.json')){$fp=Join-Path $dir $f;[pscustomobject]@{path=$fp;sha256=(SHA $fp)}})
$doc=[ordered]@{schema='air-worker.hlp03-r6-c18-transport-readback/v1';at_utc=[DateTime]::UtcNow.ToString('o');source_base_sha='e6c3c7f960208b49bdd0b4e694bc7eb99554bdce';case='C18';checks=$checks;files=$files;seed_target=$seed.target;seed_sha256=$seedSha;packet_file_terminal_whitespace='The packet file has one terminal LF absent from the embedded JSON; complete JSON and all event fields are unchanged.';verification_note='An initial exact raw-substring check rejected only that terminal LF; diagnosed before this readback. No learning rerun or frozen input change.';native_terminal='turn.completed';additional_model_calls=0;scope='Confirms complete event and seed in the captured native request, not hidden model reasoning or provider internals.'}
$out=Join-Path $t 'hlp03-r6-c18-transport-readback.json'
if(Test-Path -LiteralPath $out){throw 'C18 readback already exists'}
[IO.File]::WriteAllText($out,(($doc|ConvertTo-Json -Depth 8).Replace("`r`n","`n")+"`n"),(New-Object Text.UTF8Encoding($false)))
[ordered]@{path=$out;sha256=(SHA $out);checks=$checks;files=$files}|ConvertTo-Json -Depth 5 -Compress
