$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$p='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker';$t='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker\.air-worker\learning-loop-20261024'
function SHA([string]$f){(Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLowerInvariant()}
$before=Get-Content -LiteralPath (Join-Path $t 'hlp03-r7-preservation-before.json') -Raw -Encoding UTF8|ConvertFrom-Json
$guards=@(foreach($g in @($before.guards)+@($before.historical)){$a=SHA $g.path;[ordered]@{path=$g.path;expected=$g.sha256;actual=$a;unchanged=($a -eq $g.sha256)}})
if(@($guards|Where-Object{-not $_.unchanged}).Count){throw 'Protected/historical drift'}
$freezes=@(Get-Item -LiteralPath (Join-Path $p 'docs\tasks\HLP03_CORPUS_FREEZE_20261024_R7_DEVELOPMENT.json'),(Join-Path $p 'docs\tasks\HLP03_CORPUS_FREEZE_20261024_R7_HOLDOUT.json'))
$follow=Join-Path $p 'docs\tasks\HLP03_CORPUS_FREEZE_20261024_R7_FOLLOWUP.json'
if(Test-Path -LiteralPath $follow){$freezes+=Get-Item -LiteralPath $follow}
$bindings=@()
foreach($ff in $freezes){
 $f=Get-Content -LiteralPath $ff.FullName -Raw -Encoding UTF8|ConvertFrom-Json
 foreach($pair in @(@('corpus_path','corpus_sha256'),@('gold_path','gold_sha256'),@('protocol_path','protocol_sha256'))){
  $path=Join-Path $p $f.($pair[0]);$a=SHA $path;$expected=$f.($pair[1]);$bindings+=[ordered]@{path=$path;expected=$expected;actual=$a;unchanged=($a -eq $expected)}
 }
}
foreach($item in @(@('cmd\learn_adapter.go','adapter_sha256'),@('cmd\learn_adapter_live_eval_test.go','harness_sha256'),@('docs\tasks\run-hlp03-real-reviewer-20261024.ps1','runner_sha256'),@('docs\tasks\test-run-hlp03-real-reviewer-20261024.ps1','runner_tests_sha256'),@('.air-worker\learning-loop-20261024\air-worker-hlp03-r7.exe','binary_sha256'))){
 $path=Join-Path $p $item[0];$a=SHA $path;$expected=$f.candidate_source_hashes.($item[1]);$bindings+=[ordered]@{path=$path;expected=$expected;actual=$a;unchanged=($a -eq $expected)}
}
if(@($bindings|Where-Object{-not $_.unchanged}).Count){throw 'R7 frozen binding drift'}
$runs=@();$fixtures=@()
foreach($kind in @('development','holdout','followup')){
 $dir=Join-Path $t ('hlp03-r7-'+$kind+'-20261024')
 if(-not (Test-Path -LiteralPath $dir)){continue}
 $terminalPath=Join-Path $dir 'terminal.json'
 if(-not (Test-Path -LiteralPath $terminalPath)){throw "No original terminal for $kind"}
 $s=Get-Content -LiteralPath (Join-Path $dir 'evidence\summary.json') -Raw -Encoding UTF8|ConvertFrom-Json
 foreach($c in $s.cases){
  $ix=[Array]::IndexOf([object[]]$c.adapter.args,'-product')
  if($ix -lt 0){throw 'Fixture path missing'}
  $path=[string]$c.adapter.args[$ix+1]
  $fixtures+=[ordered]@{series=$kind;case=$c.id;path=$path;absent=(-not (Test-Path -LiteralPath $path))}
 }
 $term=Get-Content -LiteralPath $terminalPath -Raw -Encoding UTF8|ConvertFrom-Json
 $runs+=[ordered]@{series=$kind;declared_case_count=$s.case_count;completed_record_count=@($s.cases).Count;original_terminal=$term;terminal_sha256=(SHA $terminalPath);summary_sha256=(SHA (Join-Path $dir 'evidence\summary.json'))}
}
if(@($fixtures|Where-Object{-not $_.absent}).Count){throw 'Fixture root still exists'}
$partial=Join-Path $t 'qa-temp\TestHLP03RealReviewerCorpusC1510420697'
$partialFiles=@(Get-ChildItem -LiteralPath $partial -Recurse -File -Force | ForEach-Object {[ordered]@{relative=$_.FullName.Substring($partial.Length+1);bytes=$_.Length;sha256=(SHA $_.FullName)}})
$tempFiles=@(Get-ChildItem -LiteralPath (Join-Path $t 'qa-temp') -Recurse -File -Force | ForEach-Object {[ordered]@{relative=$_.FullName.Substring((Join-Path $t 'qa-temp').Length+1);bytes=$_.Length;sha256=(SHA $_.FullName)}})
$doc=[ordered]@{interrupted_fixture=[ordered]@{case='C15';path=$partial;preserved=$true;files=$partialFiles;native_completion='NOT_OBSERVED';cleanup='NOT_COMPLETED_WRAPPER_TERMINATED_GO';inference='Seed initialization was interrupted before the harness persisted its model prompt/config and invoked the reviewer.'};temp_file_inventory=$tempFiles;schema='air-worker.hlp03-r7-postrun-readback/v1';at_utc=[DateTime]::UtcNow.ToString('o');guards=$guards;frozen_bindings=$bindings;fixture_roots=$fixtures;runs=$runs;qa_temp_files=(Get-ChildItem -LiteralPath (Join-Path $t 'qa-temp') -Recurse -File -Force|Measure-Object).Count;original_terminals_preserved=$true;not_a_reconstructed_success_terminal=$true}
$out=Join-Path $t 'hlp03-r7-postrun-readback.json'
if(Test-Path -LiteralPath $out){throw 'Postrun record already exists'}
[IO.File]::WriteAllText($out,(($doc|ConvertTo-Json -Depth 16).Replace("`r`n","`n")+"`n"),(New-Object Text.UTF8Encoding($false)))
[ordered]@{path=$out;sha256=(SHA $out);guards_unchanged=$guards.Count;frozen_bindings_unchanged=$bindings.Count;completed_fixture_roots_absent=$fixtures.Count;interrupted_fixture_files=$partialFiles.Count;qa_temp_files=$doc.qa_temp_files;runs=$runs.Count}|ConvertTo-Json -Depth 3 -Compress