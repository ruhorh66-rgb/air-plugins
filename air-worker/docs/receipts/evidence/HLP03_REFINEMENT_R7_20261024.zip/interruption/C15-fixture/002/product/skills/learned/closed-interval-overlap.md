# Include shared endpoints when comparing closed intervals

## When to apply
When two finite intervals have valid ordered endpoints with start <= end and the overlap mode is closed. Closed is also the existing default when no mode is supplied.

## Procedure
1. Use the declared closed mode, or closed when the mode is absent.
2. Report overlap exactly when max(start1, start2) <= min(end1, end2).
3. Treat a shared endpoint as overlap, including a valid zero-length closed interval.

## Pitfalls
Do not silently switch the interval mode. A strict comparison would lose valid shared-endpoint overlap. This procedure assumes the supplied endpoints are correctly ordered.
