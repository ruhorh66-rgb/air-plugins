# Normalize explicit length units before comparison

## When to apply
When already parsed numeric lengths with explicit m or mm units must be compared and raw numeric comparison would mix units.

## Procedure
1. Convert each input to metres once: m uses factor 1; mm uses factor 0.001.
2. Compare the normalized numeric values.
3. Keep the original numeric value and declared unit for display and diagnosis.

## Pitfalls
Do not convert an already normalized value again. Do not guess an unknown or missing unit; report unsupported input explicitly.
