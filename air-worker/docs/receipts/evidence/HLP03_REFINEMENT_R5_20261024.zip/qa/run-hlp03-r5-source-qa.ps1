$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$source='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker'
$task='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker\.air-worker\learning-loop-20261024'
$utf8=[Text.UTF8Encoding]::new($false)
$qaPath=Join-Path $task 'hlp03-r5-source-qa.json'
$binary=Join-Path $task 'air-worker-hlp03-r5.exe'
if((Test-Path -LiteralPath $qaPath) -or (Test-Path -LiteralPath $binary)){throw 'R5 QA evidence exists; reconcile without replay'}
if((& git -C $source rev-parse HEAD).Trim() -ne '92fd3ce9ad71f6ea5fe7c8252a341191ce4d6619'){throw 'Unexpected source HEAD'}
$env:GOCACHE=Join-Path $task 'gocache'
$env:GOTMPDIR=Join-Path $task 'qa-temp'
$env:TEMP=$env:GOTMPDIR
$env:TMP=$env:GOTMPDIR
$env:AIR_WORKER_HOOK_STATE_DIR=Join-Path $task 'session'
Remove-Item Env:\AIR_WORKER_HLP03_LIVE -ErrorAction SilentlyContinue
$tokens=$null
$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $source 'docs\tasks\run-hlp03-real-reviewer-20261024.ps1'),[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count -ne 0){throw 'Existing runner parse failed'}
$footprint=$ast.Find({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Get-AwFootprint'},$true)
if(-not $footprint){throw 'Existing footprint helper absent'}
. ([scriptblock]::Create($footprint.Extent.Text))
$before=[ordered]@{cache=(Get-AwFootprint $env:GOCACHE);temp=(Get-AwFootprint $env:GOTMPDIR)}
$diskBefore=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='R:'"
if(-not $before.cache.complete -or -not $before.temp.complete -or $before.temp.files -ne 0){throw 'QA metadata incomplete or temp busy'}
if($diskBefore.FreeSpace -lt 10737418240 -or $diskBefore.FreeSpace -lt $diskBefore.Size*0.10){throw 'Shared volume reserve not met'}
Set-Location -LiteralPath (Join-Path $source 'cmd')
& gofmt -w learn_adapter.go
if($LASTEXITCODE -ne 0){throw 'gofmt failed'}
$start=[DateTime]::UtcNow
$pattern='^(TestLearningReviewer|TestHLP03)'
$raw=@(& go test . -run $pattern -count=1 -timeout 180s -json 2>&1)
$testExit=$LASTEXITCODE
$testLog=Join-Path $task 'hlp03-r5-source-go-test.jsonl'
[IO.File]::WriteAllLines($testLog,[string[]]$raw,$utf8)
$records=@($raw|ForEach-Object{if($_ -is [string] -and $_.StartsWith('{')){$_|ConvertFrom-Json}})
$passed=@($records|Where-Object{$_.Action -eq 'pass' -and $_.Test}|ForEach-Object{$_.Test})
$failed=@($records|Where-Object{$_.Action -eq 'fail' -and $_.Test}|ForEach-Object{$_.Test})
$skipped=@($records|Where-Object{$_.Action -eq 'skip' -and $_.Test}|ForEach-Object{$_.Test})
$vetExit=$null
$buildExit=$null
if($testExit -eq 0){
 $vet=@(& go vet . 2>&1)
 $vetExit=$LASTEXITCODE
 [IO.File]::WriteAllLines((Join-Path $task 'hlp03-r5-source-vet.txt'),[string[]]$vet,$utf8)
 if($vetExit -eq 0){
  $build=@(& go build -o $binary . 2>&1)
  $buildExit=$LASTEXITCODE
  [IO.File]::WriteAllLines((Join-Path $task 'hlp03-r5-source-build.txt'),[string[]]$build,$utf8)
 }
}
$diff=@(& git -C $source -c core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol diff --check -- cmd/learn_adapter.go)
$diffExit=$LASTEXITCODE
$after=[ordered]@{cache=(Get-AwFootprint $env:GOCACHE);temp=(Get-AwFootprint $env:GOTMPDIR)}
$diskAfter=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='R:'"
$hashes=[ordered]@{}
foreach($p in @('cmd\learn_adapter.go','cmd\learn_adapter_live_eval_test.go','docs\tasks\run-hlp03-real-reviewer-20261024.ps1')){$hashes[$p]=(Get-FileHash -LiteralPath (Join-Path $source $p) -Algorithm SHA256).Hash.ToLowerInvariant()}
$doc=[ordered]@{schema='air-worker.hlp03-r5-source-qa/v1';source_base_sha='92fd3ce9ad71f6ea5fe7c8252a341191ce4d6619';started_at_utc=$start.ToString('o');finished_at_utc=[DateTime]::UtcNow.ToString('o');authoring='Coordinator-specified generic paragraph applied by deterministic edit; zero coding-model calls';test_command=('go test . -run '+$pattern+' -count=1 -timeout 180s -json');test_exit_code=$testExit;passed=$passed;failed=$failed;skipped=$skipped;vet_exit_code=$vetExit;build_exit_code=$buildExit;diff_check_exit_code=$diffExit;source_sha256=$hashes;binary_path=$binary;binary_sha256=$(if($buildExit -eq 0){(Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});test_log_sha256=(Get-FileHash -LiteralPath $testLog -Algorithm SHA256).Hash.ToLowerInvariant();resources_before=$before;resources_after=$after;r_free_bytes_before=[int64]$diskBefore.FreeSpace;r_free_bytes_after=[int64]$diskAfter.FreeSpace;working_estimate_bytes=2147483648;hard_quota=$false;continuous_peak_proven=$false;full_DEV137_acceptance='NOT_CLAIMED';model_quality='NOT_MEASURED';production_effect='NOT_PROVEN';unchanged_mechanism_qa_reused='R4 schema/runner/process-tree QA remains applicable; only prompt text changed'}
[IO.File]::WriteAllText($qaPath,($doc|ConvertTo-Json -Depth 12),$utf8)
[pscustomobject]@{test_exit=$testExit;passed=$passed.Count;failed=$failed.Count;skipped=$skipped.Count;vet_exit=$vetExit;build_exit=$buildExit;diff_exit=$diffExit;qa=$qaPath;binary_sha256=$doc.binary_sha256;adapter_sha256=$hashes['cmd\learn_adapter.go'];cache_temp_after=$(if($after.cache.complete -and $after.temp.complete){$after.cache.bytes+$after.temp.bytes}else{$null});temp_files_after=$after.temp.files}|ConvertTo-Json -Compress
if($testExit -ne 0 -or $vetExit -ne 0 -or $buildExit -ne 0 -or $diffExit -ne 0 -or -not $after.cache.complete -or -not $after.temp.complete -or $after.temp.files -ne 0){exit 1}
exit 0
