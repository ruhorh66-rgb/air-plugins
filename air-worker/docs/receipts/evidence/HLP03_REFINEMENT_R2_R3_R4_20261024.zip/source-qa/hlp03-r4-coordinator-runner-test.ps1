
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$ErrorActionPreference='Stop'
$awSource='R:\-4-\air-worker\worktrees\airworker-learning-loop-20261024\air-worker'
$awTask=Join-Path $awSource '.air-worker\learning-loop-20261024'
$env:TEMP=Join-Path $awTask 'qa-temp'
$env:TMP=$env:TEMP
& (Join-Path $awSource 'docs\tasks\test-run-hlp03-real-reviewer-20261024.ps1')
if(-not $?){throw 'Existing source tests failed'}
$tokens=$null
$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $awSource 'docs\tasks\run-hlp03-real-reviewer-20261024.ps1'),[ref]$tokens,[ref]$parseErrors)
foreach($name in @('Get-AwFootprint','Stop-AwOwnedGo')){
$f=$ast.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
. ([scriptblock]::Create($f.Extent.Text))
}
$caseRoot=Join-Path $env:TEMP ('hlp03-owned-tree-'+[guid]::NewGuid().ToString('n'))
New-Item -ItemType Directory -Path $caseRoot|Out-Null
$utf8=New-Object Text.UTF8Encoding($false)
$childPidFile=Join-Path $caseRoot 'child.pid'
$parentFile=Join-Path $caseRoot 'parent.ps1'
$parentBody='$child=Start-Process powershell.exe -ArgumentList ''-NoProfile'',''-Command'',''Start-Sleep -Seconds 15'' -PassThru -WindowStyle Hidden'+[Environment]::NewLine+'[IO.File]::WriteAllText('''+$childPidFile+''',[string]$child.Id)'+[Environment]::NewLine+'Start-Sleep -Seconds 15'
[IO.File]::WriteAllText($parentFile,$parentBody,$utf8)
$parent=$null
$childProcess=$null
try{
$parent=Start-Process powershell.exe -ArgumentList '-NoProfile','-File',$parentFile -PassThru -WindowStyle Hidden
$parentHandle=$parent.Handle
$until=[DateTime]::UtcNow.AddSeconds(5)
while(-not (Test-Path -LiteralPath $childPidFile)){
if([DateTime]::UtcNow -gt $until){throw 'Disposable child handshake timeout'}
Start-Sleep -Milliseconds 100
}
$childId=[int](Get-Content -Raw -LiteralPath $childPidFile)
$childProcess=Get-Process -Id $childId
$childHandle=$childProcess.Handle
$watch=[Diagnostics.Stopwatch]::StartNew()
$killOutput=Stop-AwOwnedGo $parent
$watch.Stop()
$parent.Refresh()
$childProcess.Refresh()
$r=[ordered]@{schema='air-worker.hlp03-coordinator-runner-qa/v1';at_utc=[DateTime]::UtcNow.ToString('o');source_test_pass=$true;parent_pid=$parent.Id;child_pid=$childId;parent_exited=$parent.HasExited;child_exited=$childProcess.HasExited;cleanup_seconds=$watch.Elapsed.TotalSeconds;taskkill_output=$killOutput;runner_sha256=(Get-FileHash -Algorithm SHA256 (Join-Path $awSource 'docs\tasks\run-hlp03-real-reviewer-20261024.ps1')).Hash.ToLowerInvariant();model_calls=0;note='Actual disposable parent and descendant; task-owned process test, no services.'}
if(-not $r.parent_exited -or -not $r.child_exited){throw 'Owned process tree not fully stopped'}
[IO.File]::WriteAllText((Join-Path $awTask 'hlp03-r4-coordinator-runner-qa.json'),(($r|ConvertTo-Json -Depth 10).Replace("`r`n","`n")+"`n"),$utf8)
$r|ConvertTo-Json -Depth 10 -Compress
}finally{
foreach($p in @($parent,$childProcess)){if($p -and -not $p.HasExited){$p.Kill();$p.WaitForExit(30000)|Out-Null}}
Remove-Item -LiteralPath $caseRoot -Recurse -Force
}
